
const express = require("express");
const morgan = require("morgan");
const bodyParser = require("body-parser");
const cors = require("cors");
const uuid = require("uuid");

const fs = require("fs");


const app = express();


app.use(morgan("tiny"));
app.use(bodyParser.json());
app.use(cors());

 app.use('/static', express.static('front'));

 app.get('/',(req,res) => {
    res.redirect('/static/html_site.html')
})

// Create
app.post("/email", (req, res) => {
  const emailList = readJSONFile();
   const newEmail=req.body;
   const newEmailList=[...emailList,newEmail];
   writeJSONFile(newEmailList);
   res.json(newEmail);
  
});



// Read 
app.get("/email", (req, res) => {
  const emailList = readJSONFile();
  res.json(emailList);
});

// Update
app.put("/email/:id", (req, res) => {
  const emailList = readJSONFile();
  const id = req.params.id;
	  const newEmail = req.body;
	  newEmail.id = id;
	  idFound = false;
	
	  const newEmailList = emailList.map((email) => {
	     if (email.id === id) {
	       idFound = true;
	       return newEmail
	     }
	    return email
	  })
	  
	  writeJSONFile(newEmailList);
	
	  if (idFound) {
	    res.json(newEmail);
	  } else {
	    res.status(404).send(`email ${id} was not found`);
	  }


});


// Functia de citire 
function readJSONFile() {
  return JSON.parse(fs.readFileSync("db.json"))["email"];
}

// Functia de scriere 
function writeJSONFile(content) {
  fs.writeFileSync(
    "db.json",
    JSON.stringify({ email: content }),
    "utf8",
    err => {
      if (err) {
        console.log(err);
      }
    }
  );
}


app.listen("3000", () =>
  console.log("Server started at: http://localhost:3000")
);

