

function validateForm(mail) 
{ var z = document.forms["gmail"]["adresa_email"].value;
 if (/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(z))
  {
    return true;
  }
    var x=setTimeout(alert("You have entered an invalid email address!"),3000);
    return false;
}


function mouseEv(){
  document.getElementById("blog").addEventListener("mouseover",mouseOver);}

function mouseOver() {

  document.getElementById("blog").style.color = " rgb(226, 102, 139)";
}

function mouseOut() {
  document.getElementById("blog").style.color = "cornsilk";

}


function startTime() {
    var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementsByTagName("div")[1].innerHTML = h + ":" + m + ":" + s;
    var t = setTimeout(function(){ startTime() }, 500);
  }
  
  function checkTime(i) {
    if (i < 10) {
      i = "0" + i;
    }
    return i;
  }



  function clickCounter() {
    if(typeof(Storage) !== "undefined") {
      if (localStorage.clickcount) {
        localStorage.clickcount = Number(localStorage.clickcount)+1;
      } else {
        localStorage.clickcount = 1;
      }
      document.getElementById("result").innerHTML = "You have liked our content " + localStorage.clickcount + " time(s). Thanks for your support!";
    } 
  }


  function creare_element() {
    var y = document.createElement("A");
    var x=document.getElementById("imag_about");
    x.style.height=300 +"px";
  var link = document.createTextNode("https://instagram.com/anddaaak?r=nametag");
  y.appendChild(link); 
 
    y.title ="https://instagram.com/anddaaak?r=nametag";
     y.href=" https://instagram.com/anddaaak?r=nametag"
    document.getElementById('clr_about').appendChild(y);

  }
  function stergere_element() {
    var para = document.getElementById('clr_about').lastElementChild;
    var x=document.getElementById("imag_about");
    x.style.height=260 +"px";
    para.remove();
 
  }

 
function setColor() {
  var randomColor = Math.floor(Math.random()*16777215).toString(16);
  var x = document.getElementById("visit");
  x.style.backgroundColor = x.style.backgroundColor == "lavender" ? "#"+randomColor : "lavender";
}
var myVar = setInterval(setColor, 10000);


function schimb_fundal() {

  document.querySelector("#gridul").classList.toggle("schimba");
  
}

function  proprietati() {
  document.getElementById("idd").maxLength = "21";
  document.getElementById("idd").value = "ex: arielbeauty@gmail.com";
}

  function upp(){
    document.getElementById("idd").addEventListener("keyup",upper);}

 function upper() {
  var x = document.getElementById("idd");
  x.value = x.value.toUpperCase();

}


function culori_email() {
  document.getElementById("idd").style.backgroundColor = "#5bad5b";
  document.getElementById("idd").style.color = "black";
}
function culori(){
document.getElementById("idd").addEventListener("keydown",culori_email);
}


function randomize(){
var getRandom = (min, max) => Math.floor(Math.random()*(max-min+1)+min);
var square= document.getElementById('butonul');
square.style.left= getRandom(0, 300 )+'px'; 
// setInterval(() => {
//    square.style.left= getRandom(0, 300 - 200)+'px'; 
//    square.style.top = getRandom(0, 300 - 200)+'px';
    
// }, 500);
}

function show_about(){
  var x=document.getElementById("abm");
  x.style.display="block";
  var elmnt = document.getElementById("abm");
  elmnt.scrollIntoView();
  var x = document.getElementsByClassName("header");
  var i;
  for(i=0;i<x.length;i++)
  x[i].style.color ="pink";
  
  }
  function show_tutorial(){
    var x=document.getElementById("tutorial");
    x.style.display="block";
    var elmnt = document.getElementById("tutorial");
    elmnt.scrollIntoView();
    }

function topFunction() {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
  document.getElementById("abm").style.display="none";
  document.getElementById("tutorial").style.display="none";

}
function array(){
var steps= [1,2,3];
steps.forEach(myFunction);
}

function myFunction(item) {
  document.getElementById("pasi").innerHTML += "Step " + item + "!   "; 
}

function alerta(event) { 
  alert("You can't click on "+event.target.innerHTML+", or on "+event.currentTarget.nodeName+"/ screen");

  }

  
  function getArticlesFromServer() {
    fetch('http://localhost:3000/articles')
        .then(function (response) {
            // Trasform server response to plain object
            response.json().then(function (articles) {
                renderArticlesListPage(articles);
            });
        });
};


// Add article
function addArticleToServer() {
  const email = document.getElementById('email');
const  male = document.getElementById(' male');
const female = document.getElementById('female');
const other = document.getElementById('other');
const  mk = document.getElementById(' mk');
const hr = document.getElementById('hr');
const sc = document.getElementById('sc');
    // creat post object
    const postObject = {
        email: emailul.value,
        male: male.value,
        female: female.value,
        other: other.value,
        mk: mk.value,
        hr: hr.value,
        sc: sc.value


      
    }
    // Call post request to add a new article
    fetch('http://localhost:3000/articles', {
        method: 'post',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(postObject)
    }).then(function () {
        // Get the new article list
        getArticlesFromServer();

        // Reset Form
        resetForm();

        // Close Modal
        closeModal();
    });
}
  
